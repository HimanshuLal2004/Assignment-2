﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
namespace FlightBookingProject
{
    [Serializable]
    class Reservation
    {
        public string ReservationCode { get; set; }
        public Flight flight { get; set; }
        public string TravelerName { get; set; }

        public string Citizenship { get; set; }

        public bool IsActive { get; set; }

        public override string ToString()
        {
            var act = "";
            act = IsActive ? "Active" : "Inactive";
            return $"Reservation Code:{ReservationCode}\n FlightDetail:{flight.ToString()} \n Traveller Name:{TravelerName}\n Citizenship:{Citizenship}\n IsActive:{act}";

        }
    }
}
