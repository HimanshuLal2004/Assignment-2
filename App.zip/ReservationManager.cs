﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
namespace FlightBookingProject
{
    [Serializable]
    class ReservationManager
    {
        

        public List<Flight> FindFlights(string origin, string destination, string dayOfWeek)
        {
       
            List<Flight> matchingFlights = new List<Flight>();
            string filePath = @"C:\Users\Maninderpal Singh\Desktop\mukul\flights.csv";
            StreamReader reader = null;
            if (File.Exists(filePath))
            {
                reader = new StreamReader(File.OpenRead(filePath));
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (values[2] == origin && values[3] == destination && values[4] == dayOfWeek)
                    {
                        Flight flight = new Flight()
                        {
                            FlightCode = values[0],
                            Airline = values[1],

                            Origin = values[2],
                            Destination = values[3],
                            Day = values[4],
                            DepartureTime = DateTime.Parse(values[5]),
                            Cost = Int16.Parse(values[6])

                        };
                        matchingFlights.Add(flight);

                    }

                }


            }
            else
            {
                Console.WriteLine("File does not exist1");
            }



            return matchingFlights;
        }

        public Reservation makereservation(Flight flight, string travelername, string citizenship)
        {




            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var digits = new Random().Next(1000, 9999);
            var code = chars[digits % 10] + digits.ToString();


            
            Reservation reservation = new Reservation()
            {
                ReservationCode = code,
                flight = flight,
                TravelerName = travelername,
                Citizenship = citizenship,
                IsActive = true
            };


            persist(reservation);

            return reservation;
        }
        public void persist(Reservation reservation, List<Reservation> new_list = null)
        {

            if (new_list != null)
            {
                using (var fileStream = new FileStream(@"C:\\Users\\Maninderpal Singh\\Desktop\\mukul\\reservations.bin", FileMode.Create))
                {
                    var bFormatter = new BinaryFormatter();
                    bFormatter.Serialize(fileStream, new_list);
                }
            }
            else
            {
                List<Reservation> reservations = new List<Reservation>();
                reservations = findreservations();
                if (reservations == null)
                {
                    reservations = new List<Reservation>();
                }

                reservations.Add(reservation);


                using (var fileStream = new FileStream(@"C:\\Users\\Maninderpal Singh\\Desktop\\mukul\\reservations.bin", FileMode.Append))
                {
                    var bFormatter = new BinaryFormatter();
                    bFormatter.Serialize(fileStream, reservations);
                }
            }



        }


        public List<Reservation> findreservations()
        {
            if (!File.Exists(@"C:\\Users\\Maninderpal Singh\\Desktop\\mukul\\reservations.bin"))
            {
                return null;
            }
            List<Reservation> reservations = new List<Reservation>();

            BinaryFormatter formatter = new BinaryFormatter();
            using (var fs = new FileStream(@"C:\\Users\\Maninderpal Singh\\Desktop\\mukul\\reservations.bin", FileMode.OpenOrCreate))
            {
                var bFormatter = new BinaryFormatter();
                while (fs.Position != fs.Length)
                {
                    var t = (List<Reservation>)(bFormatter.Deserialize(fs));
                    reservations.AddRange(t);
                }
            }


            return reservations;
        }
        public Reservation findreservations(string reservationcode)
        {
            List<Reservation> reservations = new List<Reservation>();



            BinaryFormatter formatter = new BinaryFormatter();
            using (var fs = new FileStream(@"C:\\Users\\Maninderpal Singh\\Desktop\\mukul\\reservations.bin", FileMode.Open))
            {
                var bFormatter = new BinaryFormatter();
                while (fs.Position != fs.Length)
                {
                    var t = (List<Reservation>)(bFormatter.Deserialize(fs));
                    reservations.AddRange(t);
                }
            }
            try
            {
                Reservation result = reservations.Single(s => s.ReservationCode == reservationcode);
                return result;

            }
            catch
            {
                return null;

            }


        }

        public Reservation modifyreservation(Reservation reservation,string name=null,string citi=null,string active=null)
        {
            List<Reservation> reservations = findreservations();
            if (reservations == null)
            {
                return null;
            }
          //  try
         //   {
                var index = reservations.FindIndex(c => c.ReservationCode == reservation.ReservationCode);
                
                reservations[index].TravelerName = name;
                reservations[index].Citizenship = citi;
                reservations[index].IsActive = active == "Active" ? true : false;
                persist(null, reservations);
                return reservations[index];


           // }
           // catch
           // {
             //   return null;
            //}
        }
    }
}
