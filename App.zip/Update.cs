﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightBookingProject
{
    public partial class Update : Form
    {
        public Update()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtFrom_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtFrom.Text == "")
            {
                MessageBox.Show("Enter valid code!", "Warning");
            }
            else
            {
                reservation = reservationManager.findreservations(txtFrom.Text);
                if (reservation != null)
                {
                    label6.Text = reservation.ToString();


                }
                else
                {
                    MessageBox.Show("No reservation found!", "Show");
                }

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var new_reservation = reservationManager.modifyreservation(reservation, textBox1.Text, textBox2.Text, textBox3.Text);
                if (new_reservation == null)
                {
                    MessageBox.Show("Something wrong happened!", "MEssage");
                }
                else
                {
                    MessageBox.Show(new_reservation.ToString(), "New reservation details");

                }
                //MessageBox.Show("Done", "Reservation added");
            }
            catch
            {
                MessageBox.Show("Please check your details!","Error!");
            }
        }

        private void Update_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
