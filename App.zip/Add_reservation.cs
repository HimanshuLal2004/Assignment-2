﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightBookingProject
{
    public partial class Add_reservation : Form
    {
        public Add_reservation()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Update_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Flight flight=null;
            Reservation temp = null;
            try
            {
                foreach (Flight x in flights)
                {
                    if (x.FlightCode == textBox1.Text.ToString())
                    {
                        flight = x;
                        break;
                    }
                }

                var citi = textBox2.Text;

                var name = textBox3.Text;

                temp = reservationManager.makereservation(flight, name, citi);
                MessageBox.Show(temp.ToString(), "Reservation added");

            }
            catch
            {
                MessageBox.Show("Enter valid details", "Warning!");

            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtFrom.Text == "" || txtTo.Text == "" || Day.SelectedItem == null)
            {
                MessageBox.Show("Enter Valid Inputs", "Warning");

            }
            else
            {
                string to;
                string from;
                string day;
                to = txtFrom.Text;
                from = txtTo.Text;
                day = Day.SelectedItem.ToString();
                flights = reservationManager.FindFlights(from, to,
                            day);
                string result = "";
                foreach (Flight flight in flights)
                {
                    result += flight.ToString();
                }
                if (result == "")
                {

                    MessageBox.Show("No Flights", "Warning");

                }
                else
                {
                    flight_show.Text = result;
                }
            }
        }

        private void flight_show_Click(object sender, EventArgs e)
        {

        }
    }
}
