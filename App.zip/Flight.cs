﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
namespace FlightBookingProject
{
    [Serializable]
    class Flight
    {
        public string Origin { get; set; }
        public string Destination { get; set; }
        public string Day { get; set; }
        public string FlightCode { get; set; }
        public string Airline { get; set; }
        public DateTime DepartureTime { get; set; }
        public decimal Cost { get; set; }

        public override string ToString()
        {
            return $"FLight Code:{FlightCode}\n Airline:{Airline}\n Origin-Destination: {Origin} - {Destination} \n Day:{Day} \n Time:{DepartureTime}, \nCost: {Cost}";
        }
    }

}

