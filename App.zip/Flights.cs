﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightBookingProject
{
    public partial class Flights : Form
    {

        public Flights()
        {
            InitializeComponent();
        }

        private void Flights_Load(object sender, EventArgs e)
        {

        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtFrom.Text == "" || txtTo.Text == "" || Day.SelectedItem == null)
            {
                MessageBox.Show("Enter Valid Inputs", "Warning");

            }
            else
            {

                string to;
                string from;
                string day;
                to = txtFrom.Text;
                from = txtTo.Text;
                day = Day.SelectedItem.ToString();
                List<Flight> flights = reservationManager.FindFlights(from, to,
                            day);
                string result = "";
                foreach (Flight flight in flights)
                {
                    result += flight.ToString();
                }
                if (result == "")
                {

                    MessageBox.Show("No Flights", "Warning");

                }
                else
                {
                    flight_show.Text = result;

                }
            }
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            Home bForm = new Home();
            bForm.Show();
            this.Close();

        }
    }
}
